- Xin chào, tôi là Trương Gia Hy a.k.a. HyTommy - người viết plugin Hy_Badword. 
- Cảm ơn bạn đã sử dụng plugin của tôi ^^. 
- Nếu phát hiện bug (lỗi) hoặc đóng góp ý kiến về chức năng, cách vận hành của plugin 
thì hãy liên lạc với tôi qua facebook (https://fb.com/100007534232171). Tôi rất cảm kích khi bạn làm thế ^^.

- Về plugin, hãy gõ badword vào tin nhắn riêng với bot, bot sẽ nói chi tiết hơn.
- Một lần nữa cảm ơn bạn vì đã sử dụng plugin của tôi ^^.
- VÀ TÔI YÊU DUNG <3
	